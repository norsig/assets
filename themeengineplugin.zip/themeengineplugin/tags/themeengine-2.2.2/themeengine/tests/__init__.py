# -*- coding: utf-8 -*-
#
# Copyright (c) 2013-2020 Olemis Lang <olemis@gmail.com>
# All rights reserved.
#
# This software is licensed as described in the file COPYING, which
# you should have received as part of this distribution.
#

"""Tests for TracThemeEngine plugin
"""
