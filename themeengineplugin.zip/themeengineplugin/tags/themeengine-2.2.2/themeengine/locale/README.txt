
Copyright (c) 2014      Olemis Lang <olemis+trac@gmail.com>

Translation catalogs for ThemeEnginePlugin

http://trac-hacks.org/wiki/ThemeEnginePlugin
http://trac-hacks.org/ticket/11606
